-- Draw Me One · initial schema v1.0 · 2026-11-16
-- Compatible target: MySQL 8.0+ or MariaDB 10.6+ using InnoDB.
-- Create your database and database user in Hostinger FIRST.
-- In phpMyAdmin, select that database and import this file.
-- Deliberately no CREATE DATABASE/USE, credentials, admin users, or live prices.
-- Amounts are integer minor units (cents), never floating point.
-- Store private media outside the webroot; storage_key is never a public URL.
-- Timestamps are to be stored/treated as UTC by the application.

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE IF NOT EXISTS dmo_schema_migrations (
  version VARCHAR(100) NOT NULL PRIMARY KEY,
  applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dmo_users (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  display_name VARCHAR(120) NOT NULL,
  email VARCHAR(254) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'customer',
  account_status VARCHAR(24) NOT NULL DEFAULT 'pending_verification',
  email_verified_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_dmo_users_email (email),
  KEY idx_dmo_users_status (account_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dmo_auth_tokens (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  purpose VARCHAR(32) NOT NULL,
  token_hash CHAR(64) NOT NULL,
  expires_at DATETIME NOT NULL,
  consumed_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_dmo_auth_token_hash (token_hash),
  KEY idx_dmo_auth_user_purpose (user_id, purpose),
  KEY idx_dmo_auth_expires (expires_at),
  CONSTRAINT fk_dmo_auth_user FOREIGN KEY (user_id) REFERENCES dmo_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dmo_sessions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  session_hash CHAR(64) NOT NULL,
  expires_at DATETIME NOT NULL,
  last_seen_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_dmo_session_hash (session_hash),
  KEY idx_dmo_session_user (user_id),
  KEY idx_dmo_session_expires (expires_at),
  CONSTRAINT fk_dmo_session_user FOREIGN KEY (user_id) REFERENCES dmo_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dmo_commission_tiers (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  slug VARCHAR(80) NOT NULL,
  name VARCHAR(120) NOT NULL,
  description TEXT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'CAD',
  estimate_min_minor INT UNSIGNED NULL,
  estimate_max_minor INT UNSIGNED NULL,
  features_json LONGTEXT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_dmo_tier_slug (slug),
  KEY idx_dmo_tier_active_order (is_active, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dmo_addons (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  slug VARCHAR(80) NOT NULL,
  name VARCHAR(120) NOT NULL,
  description TEXT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'CAD',
  estimate_min_minor INT UNSIGNED NULL,
  estimate_max_minor INT UNSIGNED NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_dmo_addon_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dmo_tier_addons (
  tier_id BIGINT UNSIGNED NOT NULL,
  addon_id BIGINT UNSIGNED NOT NULL,
  is_available TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (tier_id, addon_id),
  CONSTRAINT fk_dmo_ta_tier FOREIGN KEY (tier_id) REFERENCES dmo_commission_tiers(id) ON DELETE CASCADE,
  CONSTRAINT fk_dmo_ta_addon FOREIGN KEY (addon_id) REFERENCES dmo_addons(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dmo_commission_requests (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  public_ref VARCHAR(32) NOT NULL,
  customer_id BIGINT UNSIGNED NOT NULL,
  tier_id BIGINT UNSIGNED NULL,
  tier_snapshot_json LONGTEXT NULL,
  subject_type VARCHAR(80) NOT NULL DEFAULT 'other',
  brief LONGTEXT NOT NULL,
  preferred_contact VARCHAR(32) NOT NULL DEFAULT 'onsite',
  preferred_deadline DATE NULL,
  status VARCHAR(32) NOT NULL DEFAULT 'submitted',
  policy_version VARCHAR(40) NULL,
  submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_dmo_request_ref (public_ref),
  KEY idx_dmo_request_customer (customer_id, submitted_at),
  KEY idx_dmo_request_status (status, submitted_at),
  CONSTRAINT fk_dmo_request_customer FOREIGN KEY (customer_id) REFERENCES dmo_users(id) ON DELETE RESTRICT,
  CONSTRAINT fk_dmo_request_tier FOREIGN KEY (tier_id) REFERENCES dmo_commission_tiers(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dmo_request_addons (
  request_id BIGINT UNSIGNED NOT NULL,
  addon_id BIGINT UNSIGNED NOT NULL,
  addon_snapshot_json LONGTEXT NULL,
  PRIMARY KEY (request_id, addon_id),
  CONSTRAINT fk_dmo_ra_request FOREIGN KEY (request_id) REFERENCES dmo_commission_requests(id) ON DELETE CASCADE,
  CONSTRAINT fk_dmo_ra_addon FOREIGN KEY (addon_id) REFERENCES dmo_addons(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dmo_quotes (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  request_id BIGINT UNSIGNED NOT NULL,
  version_number INT UNSIGNED NOT NULL DEFAULT 1,
  currency CHAR(3) NOT NULL DEFAULT 'CAD',
  total_minor INT UNSIGNED NOT NULL,
  scope_description LONGTEXT NOT NULL,
  revision_allowance SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  validity_ends_at DATETIME NULL,
  status VARCHAR(32) NOT NULL DEFAULT 'draft',
  sent_at DATETIME NULL,
  accepted_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_dmo_quote_request_version (request_id, version_number),
  KEY idx_dmo_quote_status (status),
  CONSTRAINT fk_dmo_quote_request FOREIGN KEY (request_id) REFERENCES dmo_commission_requests(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dmo_quote_lines (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  quote_id BIGINT UNSIGNED NOT NULL,
  description VARCHAR(255) NOT NULL,
  amount_minor INT NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  CONSTRAINT fk_dmo_ql_quote FOREIGN KEY (quote_id) REFERENCES dmo_quotes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dmo_orders (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  request_id BIGINT UNSIGNED NOT NULL,
  accepted_quote_id BIGINT UNSIGNED NOT NULL,
  status VARCHAR(32) NOT NULL DEFAULT 'awaiting_payment',
  payment_status VARCHAR(32) NOT NULL DEFAULT 'unpaid',
  agreed_deadline DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_dmo_order_request (request_id),
  UNIQUE KEY uq_dmo_order_quote (accepted_quote_id),
  KEY idx_dmo_order_worklist (status, updated_at),
  CONSTRAINT fk_dmo_order_request FOREIGN KEY (request_id) REFERENCES dmo_commission_requests(id) ON DELETE RESTRICT,
  CONSTRAINT fk_dmo_order_quote FOREIGN KEY (accepted_quote_id) REFERENCES dmo_quotes(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dmo_payments (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  order_id BIGINT UNSIGNED NOT NULL,
  method VARCHAR(32) NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'CAD',
  amount_minor INT UNSIGNED NOT NULL,
  provider_reference VARCHAR(180) NULL,
  status VARCHAR(32) NOT NULL DEFAULT 'pending_verification',
  verified_by BIGINT UNSIGNED NULL,
  verified_at DATETIME NULL,
  private_note TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_dmo_payment_order (order_id),
  KEY idx_dmo_payment_status (status),
  CONSTRAINT fk_dmo_payment_order FOREIGN KEY (order_id) REFERENCES dmo_orders(id) ON DELETE RESTRICT,
  CONSTRAINT fk_dmo_payment_verifier FOREIGN KEY (verified_by) REFERENCES dmo_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dmo_conversations (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  request_id BIGINT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_dmo_conversation_request (request_id),
  CONSTRAINT fk_dmo_conv_request FOREIGN KEY (request_id) REFERENCES dmo_commission_requests(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dmo_messages (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  conversation_id BIGINT UNSIGNED NOT NULL,
  sender_id BIGINT UNSIGNED NOT NULL,
  body LONGTEXT NOT NULL,
  is_internal TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_dmo_messages_thread (conversation_id, created_at),
  CONSTRAINT fk_dmo_message_conversation FOREIGN KEY (conversation_id) REFERENCES dmo_conversations(id) ON DELETE RESTRICT,
  CONSTRAINT fk_dmo_message_sender FOREIGN KEY (sender_id) REFERENCES dmo_users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dmo_private_attachments (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  request_id BIGINT UNSIGNED NOT NULL,
  message_id BIGINT UNSIGNED NULL,
  storage_key VARCHAR(255) NOT NULL,
  original_filename VARCHAR(255) NOT NULL,
  mime_type VARCHAR(100) NOT NULL,
  byte_size BIGINT UNSIGNED NOT NULL,
  uploaded_by BIGINT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_dmo_private_attachment_key (storage_key),
  KEY idx_dmo_attachment_request (request_id),
  CONSTRAINT fk_dmo_attachment_request FOREIGN KEY (request_id) REFERENCES dmo_commission_requests(id) ON DELETE RESTRICT,
  CONSTRAINT fk_dmo_attachment_message FOREIGN KEY (message_id) REFERENCES dmo_messages(id) ON DELETE SET NULL,
  CONSTRAINT fk_dmo_attachment_uploader FOREIGN KEY (uploaded_by) REFERENCES dmo_users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dmo_deliverables (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  order_id BIGINT UNSIGNED NOT NULL,
  storage_key VARCHAR(255) NOT NULL,
  download_name VARCHAR(255) NOT NULL,
  mime_type VARCHAR(100) NOT NULL,
  byte_size BIGINT UNSIGNED NOT NULL,
  revision_number INT UNSIGNED NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_dmo_delivery_key (storage_key),
  KEY idx_dmo_delivery_order (order_id),
  CONSTRAINT fk_dmo_delivery_order FOREIGN KEY (order_id) REFERENCES dmo_orders(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dmo_showcase_permissions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  request_id BIGINT UNSIGNED NOT NULL,
  customer_id BIGINT UNSIGNED NOT NULL,
  consent_granted TINYINT(1) NOT NULL DEFAULT 0,
  consent_text LONGTEXT NOT NULL,
  consent_version VARCHAR(40) NOT NULL,
  recorded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  revoked_at DATETIME NULL,
  KEY idx_dmo_consent_request (request_id, recorded_at),
  CONSTRAINT fk_dmo_consent_request FOREIGN KEY (request_id) REFERENCES dmo_commission_requests(id) ON DELETE RESTRICT,
  CONSTRAINT fk_dmo_consent_customer FOREIGN KEY (customer_id) REFERENCES dmo_users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dmo_portfolio_artworks (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  request_id BIGINT UNSIGNED NULL,
  slug VARCHAR(160) NOT NULL,
  title VARCHAR(255) NULL,
  alt_text VARCHAR(500) NULL,
  visibility VARCHAR(20) NOT NULL DEFAULT 'draft',
  sort_order INT NOT NULL DEFAULT 0,
  is_featured TINYINT(1) NOT NULL DEFAULT 0,
  published_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_dmo_artwork_slug (slug),
  KEY idx_dmo_artwork_published (visibility, sort_order),
  CONSTRAINT fk_dmo_artwork_request FOREIGN KEY (request_id) REFERENCES dmo_commission_requests(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dmo_artwork_files (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  artwork_id BIGINT UNSIGNED NOT NULL,
  variant VARCHAR(24) NOT NULL,
  storage_key VARCHAR(255) NOT NULL,
  mime_type VARCHAR(100) NOT NULL,
  pixel_width INT UNSIGNED NOT NULL,
  pixel_height INT UNSIGNED NOT NULL,
  byte_size BIGINT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_dmo_artwork_variant (artwork_id, variant),
  UNIQUE KEY uq_dmo_artwork_storage (storage_key),
  CONSTRAINT fk_dmo_artfile_artwork FOREIGN KEY (artwork_id) REFERENCES dmo_portfolio_artworks(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dmo_site_settings (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  context VARCHAR(30) NOT NULL,
  version_number INT UNSIGNED NOT NULL DEFAULT 1,
  settings_json LONGTEXT NOT NULL,
  edited_by BIGINT UNSIGNED NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_dmo_settings_context (context),
  CONSTRAINT fk_dmo_settings_editor FOREIGN KEY (edited_by) REFERENCES dmo_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dmo_audit_log (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  actor_id BIGINT UNSIGNED NULL,
  action VARCHAR(120) NOT NULL,
  entity_type VARCHAR(80) NULL,
  entity_id BIGINT UNSIGNED NULL,
  details_json LONGTEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_dmo_audit_timestamp (created_at),
  KEY idx_dmo_audit_actor (actor_id, created_at),
  CONSTRAINT fk_dmo_audit_actor FOREIGN KEY (actor_id) REFERENCES dmo_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- No admin credentials, customer data, commission packages or prices are seeded.
-- Add the first admin through a one-time authenticated PHP CLI/installer that
-- hashes a chosen password using password_hash(). Never insert plain passwords.
INSERT INTO dmo_schema_migrations (version) VALUES ('001_initial_schema')
ON DUPLICATE KEY UPDATE version=VALUES(version);
